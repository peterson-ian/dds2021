<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Sistema Farmácia</title>
        <link rel="stylesheet" type="text/css" href="estilo.css" />
    </head>
    <body>
        <h1>Sistema de Farmácia</h1>
        <hr />
            <a href="form_remedio.php">Cadastrar novo remédio</a> | 
            <a href="listar_remedio.php">Listar remédios</a> |
            <a href="form_cliente.php">Cadastrar novo cliente</a> |
            <a href="listar_cliente.php">Listar clientes</a> 
        <hr />