<?php
    // Aqui eu coloco o menu padrao do sistema e ainda verifico se o usuario esta logado;
    require_once "cabecalho.php";
?>
    <!-- Home do sistema -->
    <center><h1>Bem vindo ao sistema IFRH</h1></center>

    </body>
</html>