<?php
    // Aqui eu garanto que todos que implentarem interface ExibicaoTabela terao o metodo exibir;
    Interface ExibicaoTabela{
        public function exibir();
    }

?>