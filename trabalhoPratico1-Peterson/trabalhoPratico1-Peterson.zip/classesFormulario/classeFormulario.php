<?php
    require_once "interfaceExibicao.php";
    require_once "classeInput.php";
    require_once "classeSelect.php";
    require_once "classeTextArea.php";

    class Formulario implements Exibicao{
        public $method;
        public $action;
        public $titulo;
        public $elementos_form;

        public function __construct($valores){
            $this->method = $valores["method"];
            $this->action = $valores["action"];
            $this->titulo = $valores["titulo"];
        }

        public function adiciona_elemento($e){
            $this->elementos_form[] = $e;
        }

        public function exibir(){
            echo "<form method='$this->method' action='$this->action'>";
            echo "<h2>".$this->titulo."</h2>";
            foreach($this->elementos_form as $i=>$e){
                $e->exibir();
            }

            echo "</form></fieldset>";
        }
        
    }


?>