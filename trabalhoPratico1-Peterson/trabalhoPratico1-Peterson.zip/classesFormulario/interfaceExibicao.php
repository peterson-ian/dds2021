<?php

    Interface Exibicao{
        public function exibir();
    }

?>